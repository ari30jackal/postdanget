package com.digimaster.daylima.model

data class PostJobResponse(
    val code: Int,
    val `data`: DataX,
    val status: String
)