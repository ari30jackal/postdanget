package com.digimaster.daylima.util.digicore.pref

object JayaPrefConstant {
    const val LOGIN_STATUS = "login_status"
    const val USER_TOKEN = "user_token"
    const val USER_REFRESH_TOKEN = "user_refresh_token"
    const val PETUGAS_ID = "petugas_id"
    const val PETUGAS_CODE = "petugas_code"
    const val PETUGAS_PHONE = "petugas_phone"
    const val PETUGAS_NAME = "petugas_name"
    const val SUB_DIVISI = "sub_divisi"
}