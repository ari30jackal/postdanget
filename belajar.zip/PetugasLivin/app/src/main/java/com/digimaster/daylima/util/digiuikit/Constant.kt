package com.digimaster.daylima.util.digiuikit

class Constant {
    companion object {
        const val CERTIFICATE_URL = "http://test.belarasa.id/belarasa/assets/files/certificate/"
        const val NEWS_URL = "https://appjrp.com/assets/files/news/"
        const val EVENT_URL = "https://appjrp.com/assets/files/event/"
        const val PROMO_URL = "https://appjrp.com/assets/files/promo/"
        const val EVENT_QR_CODE = "http://test.belarasa.id/belarasa/assets/files/qrcode_event/"
        const val AVATAR_URL = "http://ui-avatars.com/api/?color=ffffff&background=0A72ED&rounded=true&size=48&bold=true"
    }
}