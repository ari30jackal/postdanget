package com.digimaster.daylima.util.digiuikit

interface SearchResultCallback {
    fun onNoResultFound()
}