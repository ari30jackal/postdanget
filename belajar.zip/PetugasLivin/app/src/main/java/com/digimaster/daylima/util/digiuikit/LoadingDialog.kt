package com.digimaster.daylima.util.digiuikit

class LoadingDialog {
}