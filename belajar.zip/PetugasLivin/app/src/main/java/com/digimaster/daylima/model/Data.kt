package com.digimaster.daylima.model

data class Data(
    val jobDesc: String,
    val jobId: Int,
    val jobName: String,
    val jobSalary: Int
)