package com.digimaster.daylima.model

data class DataX(
    val jobDesc: String,
    val jobId: Int,
    val jobName: String,
    val jobSalary: Int
)